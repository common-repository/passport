=== Passport Wordpress Plugin ===

Contributors: Derek Klatt
Donate link:
Tags:
Requires at least: 4.1.10
Tested up to: 4.4.2
Stable tag: trunk
License: GPLv2 or later

== Description ==
This is a Wordpress plugin that uses Passport as the User login, logout, registration and an Oauth2 authorization endpoint. Passport is a User Database that allows you to create, register and manage your users in a single location. If you scale and create more applications, Passport can become a SSO so all your users can easily login and register between all your applications. You can download and learn more about Passport at https://www.inversoft.com/products/user-management-sso


== Installation ==
**Make sure your settings are correct before logging out!!**
= In Passport =
1. Generate an API Key.  If you want to secure your API Key click GET on /api/user. If you want any passport user to be able to login and register with wordpress you will also need POST on /api/user/registration checked
2. Create an application, click OAUTH and fill out the information needed for your Wordpress website.
3. Click manage rolls on the application you just created and create the wordpress roles. The roles are Administrator, Author, Contributor, Editor and Subscriber.
4. Record the API key, client id and client Secret for later
= In Wordpress =
1. To manually install, unzip the plugin into your wordpress directory and into wp-content/plugins
2. Or log into your wordpress site, go to plugins, add new, upload plugin and find the passport-wordpress-plugin.zip that you downloaded or built.
3. Activate the plugin
4. Once installed make sure to go into settings and configure everything properly.
5. You need to correctly enter where Passport backend and frontend are running, the client id and client secret that passport generated for wordpress and the API key for wordpress and click Save all settings.
6. If you have multiple browers, test to see if you can log in from another browser before logging out.
7. If configuration is setup incorrectly and you can't log back in, go into your plugin directory and either delete or remove the Passport plugin and start again.

= Example Settings =
* Passport Backend URI: http://127.0.0.1:9011

* Passport Frontend URI: </td><td> http://127.0.0.1:9031

* Client ID: e6430720-d546-4491-a80f-567a833530af

* Client Secret: e6430720-d546-4491-a80f-567a833530af

* API Key: e6430720-d546-4491-a80f-567a833530af


== Upgrade Notice ==
None
== Frequently Asked Questions ==
= What is Passport? =
Found out here https://www.inversoft.com/products/user-management-sso
== Changelog ==
First release
== Screenshots ==
Look at the example settings

== Get the Plugin ==
= http://savant.inversoft.org/com/inversoft/passport-wordpress-plugin/passport-wordpress-plugin/0.2.4/ =
or
= https://github.com/inversoft/passport-wordpress-plugin =